<?php
global $plain_fields;
?>
	<div id="footer">
		<div id="f_left">Theme created by <a href="http://www.lessthanweb.com/products/plain-fields">LessThanWeb</a></div>
		<div id="f_right">&copy; 2010 <?php echo $plain_fields->set_copyright() == FALSE ? bloginfo('name') : $plain_fields->set_copyright(); ?></div>
	</div><?php	//	end #footer ?>

</div><?php //	end #wrapper ?>

<?php
if ($plain_fields->set_footer_javascript() != FALSE)
{
	echo $plain_fields->set_footer_javascript();
}
?>
<?php wp_footer(); ?>

</body>
</html>
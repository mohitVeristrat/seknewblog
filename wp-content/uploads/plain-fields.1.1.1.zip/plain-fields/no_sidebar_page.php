<?php
/*
Template Name: No sidebar
*/

get_header();
?>

	<div id="content_cont">

		<div id="content_full">
<?php
if (have_posts())
{
	while (have_posts())
	{
		the_post();
?>
			<div <?php post_class('blog_page_cont'); ?>>
<?php
		if (has_post_thumbnail() == TRUE)
		{
?>
				<div class="blog_single_feature_image"><?php the_post_thumbnail(); ?></div>
<?php
		}
?>
				<h1><?php the_title(); ?></h1>
				<div class="blog_page_top"><?php edit_post_link('Edit this page', '<span class="edit-link">', '</span>' ); ?></div>
				<div class="blog_page_content">
					<?php the_content('', FALSE, ''); ?>
					<?php wp_link_pages('before=<div id="blog_page_links">'.__('Pages:', LTW_PLAIN_FIELDS_UN).'&after=</div>'); ?>
				</div>
			</div><?php	//	end .blog_page_cont ?>
<?php
	}
?>
			<?php comments_template( '', true ); ?>
<?php
}
?>
		</div><?php	//	end #content_full ?>

	</div><?php	//	end #content_cont ?>

<?php get_footer(); ?>
<?php get_header(); ?>

	<div id="content_cont">

		<div id="content_left">
<?php
if (have_posts())
{
	while (have_posts())
	{
		the_post();
?>
			<div <?php post_class('blog_post_cont'); ?>>
<?php
		if (has_post_thumbnail() == TRUE)
		{
?>
				<div class="blog_single_feature_image"><?php the_post_thumbnail(); ?></div>
<?php
		}
?>
				<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				<div class="blog_post_comments"><?php comments_open() == FALSE ? _e('<em>Comments Off</em>', LTW_PLAIN_FIELDS_UN) : printf(_n('1 Comment', '%1$s Comments', get_comments_number(), LTW_PLAIN_FIELDS_UN), number_format_i18n(get_comments_number())); ?></div>
				<div class="blog_post_content">
					<?php the_content(__('Read the rest of this post', LTW_PLAIN_FIELDS_UN)); ?>
					<?php wp_link_pages('before=<div id="blog_single_links">'.__('Pages:', LTW_PLAIN_FIELDS_UN).'&after=</div>'); ?>
				</div>
				<div class="blog_post_bottom">
					<div class="left"><?php _e('Filed under', LTW_PLAIN_FIELDS_UN); ?> <?php the_category(', '); ?></div>
					<div class="right"><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php _e('Permanent Link to', LTW_PLAIN_FIELDS_UN); ?> <?php the_title_attribute(); ?>"><?php echo get_the_date(str_ireplace('Y', '<\s\p\a\n>Y</\s\p\a\n>', get_option('date_format'))); ?></a></div>
				</div>
			</div><?php	//	end .blog_post_cont ?>
<?php
	}
}

if ($wp_query->max_num_pages > 1)
{
?>
			<div class="blog_post_navigation">
				<div class="previous"><?php next_posts_link(__('<span class="meta-nav">&larr;</span> Older posts', LTW_PLAIN_FIELDS_UN)); ?></div>
				<div class="next"><?php previous_posts_link(__('Newer posts <span class="meta-nav">&rarr;</span>', LTW_PLAIN_FIELDS_UN)); ?></div>
			</div>
<?php
}
?>
		</div><?php	//	end #content_left ?>

		<?php get_sidebar(); ?>

	</div><?php	//	end #content_cont ?>

<?php get_footer(); ?>
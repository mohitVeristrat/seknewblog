<div id="content_right">
<?php
//	All pages sidebar
if (dynamic_sidebar('all-pages-widget-area') == FALSE)
{
?>
	<div class="widget_cont">
		<h3><?php _e('Categories', LTW_PLAIN_FIELDS_UN); ?></h3>
		<ul>
			<?php wp_list_categories('title_li='); ?>
		</ul>
	</div>
	<div class="widget_cont">
		<h3><?php _e('Archives', LTW_PLAIN_FIELDS_UN); ?></h3>
		<ul>
			<?php wp_get_archives('type=monthly'); ?>
		</ul>
	</div>
	<div class="widget_cont">
		<h3><?php _e('Meta', LTW_PLAIN_FIELDS_UN); ?></h3>
		<ul>
			<?php wp_register(); ?>
			<li><?php wp_loginout(); ?></li>
			<?php wp_meta(); ?>
		</ul>
	</div>
<?php
}

if (is_home() == TRUE || is_front_page() == TRUE)
{
	//	Front page only sidebar
	if (is_active_sidebar('front-page-widget-area'))
	{
		dynamic_sidebar('front-page-widget-area');
	}
}

if (is_page() == TRUE)
{
	//	Pages only sidebar
	if (is_active_sidebar('pages-only-widget-area'))
	{
		dynamic_sidebar('pages-only-widget-area');
	}
}

if (is_single() == TRUE)
{
	//	Posts only sidebar
	if (is_active_sidebar('posts-only-widget-area'))
	{
		dynamic_sidebar('posts-only-widget-area');
	}
}
?>
</div><?php	//	end #content_right ?>
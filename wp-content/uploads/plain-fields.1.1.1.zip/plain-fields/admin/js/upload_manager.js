jQuery(document).ready(function($) {
	var img_field_alt = '';

	$('.upload_button').click(function() {
		var post_id = $(this).attr('name');
		if (post_id != '') {
			post_id = 'post_id='+post_id.replace('button_', '')+'&';
		}
		img_field_alt = $(this).attr('alt')+'_img';
		formfield = $($(this).attr('alt')+'_img').attr('name');
		tb_show('', 'media-upload.php?'+post_id+'type=image&amp;TB_iframe=true');
	 	return false;
	});

	window.send_to_editor = function(html) {
 		imgurl = $('img',html).attr('src');
 		$('#'+img_field_alt).val(imgurl);
 		tb_remove();
	}
});

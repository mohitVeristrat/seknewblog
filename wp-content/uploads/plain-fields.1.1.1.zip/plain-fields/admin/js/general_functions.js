jQuery(document).ready(function($) {
	$('.ltw_checkbox').click(function(){
		var cb_id = $(this).attr('id');

		if ($(this).attr("checked") == true) {
			$('#'+cb_id+'_checkbox').val($(this).val());
		}
		else
		{
			$('#'+cb_id+'_checkbox').val('');
		}
	});
});

Plain Fields Theme Installation Instructions:

1. Unpack the content of the zip file.
2. Upload the folder "plain-fields" to "/wp-content/themes" folder.
3. Login into your Wordpress admin area and click on "Appearance" in the menu.
4. Click on "Themes".
5. Click on the Plain Fields theme to activate it.
6. A new menu option will appear where you can set some options for this theme.
7. That's it. Have fun with it.
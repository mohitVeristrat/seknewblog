<?php get_header(); ?>

	<div id="content_cont">

		<div id="content_left">
<?php
if (have_posts())
{
	while (have_posts())
	{
		the_post();
?>
			<div <?php post_class('blog_page_cont'); ?>>
<?php
		if (has_post_thumbnail() == TRUE)
		{
?>
				<div class="blog_single_feature_image"><?php the_post_thumbnail(); ?></div>
<?php
		}
?>
				<h1><?php the_title(); ?></h1>
				<div class="blog_page_top"><?php edit_post_link('Edit this page', '<span class="edit-link">', '</span>' ); ?></div>
				<div class="blog_page_content">
					<?php the_content('', FALSE, ''); ?>
					<?php wp_link_pages('before=<div id="blog_page_links">'.__('Pages:', LTW_PLAIN_FIELDS_UN).'&after=</div>'); ?>
				</div>
<?php
		$children = wp_list_pages('title_li=&child_of='.$post->ID.'&echo=0');

		if ($children)
		{
?>
				<div class="blog_page_bottom">
					<h4><?php _e('Subpages', LTW_PLAIN_FIELDS_UN); ?></h4>
					<ul>
  						<?php echo $children; ?>
  					</ul>
  				</div>
<?php
		}
?>
			</div><?php	//	end .blog_page_cont ?>
<?php
	}
?>
			<?php comments_template( '', true ); ?>
<?php
}
?>
		</div><?php	//	end #content_left ?>

		<?php get_sidebar(); ?>

	</div><?php	//	end #content_cont ?>

<?php get_footer(); ?>
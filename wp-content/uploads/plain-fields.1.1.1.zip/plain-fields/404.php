<?php get_header(); ?>

	<div id="content_cont">

		<div id="content_left">
			<div <?php post_class('blog_page_cont'); ?>>
				<h1><?php _e("Oops, the page you were looking for doesn't exist.", LTW_PLAIN_FIELDS_UN); ?></h1>
				<div class="blog_page_content">
					<p><?php _e("Try using the search:", LTW_PLAIN_FIELDS_UN); ?></p>
					<?php get_search_form(); ?>
					<br />
					<p><?php _e("Search not good enough? Maybe some of the links below can help you.", LTW_PLAIN_FIELDS_UN); ?></p>
					<h2><?php _e("Pages", LTW_PLAIN_FIELDS_UN); ?></h2>
					<ul><?php wp_list_pages('title_li='); ?></ul>
					<h2><?php _e("Categories", LTW_PLAIN_FIELDS_UN); ?></h2>
					<ul><?php wp_list_categories('title_li='); ?></ul>
				</div>
			</div>
		</div><?php	//	end #content_left ?>

		<?php get_sidebar(); ?>

	</div><?php	//	end #content_cont ?>

<?php get_footer(); ?>
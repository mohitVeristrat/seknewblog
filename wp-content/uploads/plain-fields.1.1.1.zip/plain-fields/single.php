<?php get_header(); ?>

	<div id="content_cont">

		<div id="content_left">
<?php
if (have_posts())
{
	while (have_posts())
	{
		the_post();
?>
			<div <?php post_class('blog_single_cont'); ?>>
<?php
		if (has_post_thumbnail() == TRUE)
		{
?>
				<div class="blog_single_feature_image"><?php the_post_thumbnail(); ?></div>
<?php
		}
?>
				<h1><?php the_title(); ?></h1>
				<div class="blog_single_top">
					<div class="comments"><?php comments_open() == FALSE ? _e('<em>Comments Off</em>', LTW_PLAIN_FIELDS_UN) : printf(_n('1 Comment', '%1$s Comments', get_comments_number(), LTW_PLAIN_FIELDS_UN), number_format_i18n(get_comments_number())); ?></div>
					<div class="date"><?php printf(__('Posted by <a href="%1$s">%2$s</a> on <span>%3$s</span> at <span>%4$s</span>', LTW_PLAIN_FIELDS_UN), get_author_posts_url(get_the_author_meta('ID')), get_the_author(), get_the_date(), get_the_time()); ?></div>
				</div>
				<div class="blog_single_content">
					<?php the_content('', FALSE, ''); ?>
					<?php wp_link_pages('before=<div id="blog_single_links">'.__('Pages:', LTW_PLAIN_FIELDS_UN).'&after=</div>'); ?>
				</div>
				<div class="blog_single_bottom">
<?php
		if (get_the_tags() != FALSE)
		{
?>
					<div class="categories"><?php _e('Filed under', LTW_PLAIN_FIELDS_UN); ?> <?php the_category(', '); ?></div>
					<div class="tags"><?php the_tags(__('Tagged as ', LTW_PLAIN_FIELDS_UN), ', ', ''); ?></div>
<?php
		}
		else
		{
			if (is_attachment() == FALSE)
			{
?>
					<div class="categories_full"><?php _e('Filed under', LTW_PLAIN_FIELDS_UN); ?> <?php the_category(', '); ?></div>
<?php
			}
		}
?>
				</div>
				<div class="blog_single_extra">
<?php
		//	Comments and pings are open
		if (comments_open() == TRUE && pings_open() == TRUE)
		{
?>
					<?php printf(__('You can leave a <a href="#respond">comment</a>, or <a href="%1$s">trackback</a> from your own site.', LTW_PLAIN_FIELDS_UN), get_trackback_url()); ?>
<?php
		}
		//	Comments are closed but pings are open
		else if (comments_open() == FALSE && pings_open() == TRUE)
		{
?>
					<?php printf(__('Comments are currently closed, but you can <a href="%1$s">trackback</a> from your own site.', LTW_PLAIN_FIELDS_UN), get_trackback_url()); ?>
<?php
		}
		//	Comments are open but pings are closed
		else if (comments_open() == TRUE && pings_open() == FALSE)
		{
?>
					<?php _e('You can skip to the end and <a href="#respond">leave a comment</a>. Pinging is currently not allowed.', LTW_PLAIN_FIELDS_UN); ?>
<?php
		}
		//	Both, comments and pings are closed
		else if (comments_open() == FALSE && pings_open() == FALSE)
		{
?>
					<?php _e('Both comments and pings are currently closed.', LTW_PLAIN_FIELDS_UN); ?>
<?php
		}
?>
				</div><?php	//	end .blog_single_extra ?>
			</div><?php	//	end .blog_post_cont ?>
<?php
	}
?>
			<?php comments_template( '', true ); ?>
<?php
}
?>
		</div><?php	//	end #content_left ?>

		<?php get_sidebar(); ?>

	</div><?php	//	end #content_cont ?>

<?php get_footer(); ?>
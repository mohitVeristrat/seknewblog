<?php get_header(); ?>

	<div id="content_cont">

		<div id="content_left">
			<h1 id="cl_h1"><?php printf(__('Tag Archives: %s', LTW_PLAIN_FIELDS_UN), single_tag_title('', FALSE)); ?></h1>
<?php
if (have_posts())
{
	while (have_posts())
	{
		the_post();
?>
			<div <?php post_class('blog_post_cont'); ?>>
				<h3><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
				<div class="blog_post_comments"><?php comments_open() == FALSE ? _e('<em>Comments Off</em>', LTW_PLAIN_FIELDS_UN) : printf(_n('1 Comment', '%1$s Comments', get_comments_number(), LTW_PLAIN_FIELDS_UN), number_format_i18n(get_comments_number())); ?></div>
				<div class="blog_post_content"><?php the_content(__('Read the rest of this post', LTW_PLAIN_FIELDS_UN)); ?></div>
				<div class="blog_post_bottom">
					<div class="left"><?php _e('Filed under', LTW_PLAIN_FIELDS_UN); ?> <?php the_category(', '); ?></div>
					<div class="right"><?php echo get_the_date('M j'); ?>, <span><?php echo get_the_date('Y'); ?></span></div>
				</div>
			</div><?php	//	end .blog_post_cont ?>
<?php
	}
}

if ($wp_query->max_num_pages > 1)
{
?>
			<div class="blog_post_navigation">
				<div class="previous"><?php next_posts_link(__('<span class="meta-nav">&larr;</span> Older posts', LTW_PLAIN_FIELDS_UN)); ?></div>
				<div class="next"><?php previous_posts_link(__('Newer posts <span class="meta-nav">&rarr;</span>', LTW_PLAIN_FIELDS_UN)); ?></div>
			</div>
<?php
}
?>
		</div><?php	//	end #content_left ?>

		<?php get_sidebar(); ?>

	</div><?php	//	end #content_cont ?>

<?php get_footer(); ?>
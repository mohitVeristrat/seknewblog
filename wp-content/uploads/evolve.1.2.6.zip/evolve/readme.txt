EvoLve WordPress Theme By Theme4Press - http://theme4press.com
Theme Homepage -  http://theme4press.com/evolve
Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html
-------------------------------------------------------------------------------------------------

EvoLve is a premium WordPress theme with advanced features including lots of 
options. It features a modern design with up to 14 color variants, fully 
customizable layout, post excerpts with thumbnails, post boxes, author gravatar 
support, up to 11 subscribe/social customizable buttons, custom logo, 
header widgets, recent posts slideshow, footer widgets, 
custom footer, customizable font styles, custom CSS, ads spaces. 
The EvoLve theme also comes with custom Menus support and other cool features.

EvoLve supports Custom Header, Custom Background, Custom Menu, Widgets and 
the following extra features:

 - Pre-installed menu and content colors
 - Custom sidebars
 - Custom width
 - Support for post thumbnails
 - Custom share buttons
 - Similar posts feature
 - Custom 11 Social Share buttons
 - Custom logo
 - 4 widgetized areas in the header and footer
 - Slideshow with recent posts
 - Custom footer
 - Custom fonts and CSS styles
 - Back to Top button
 - 9 Ads Spaces


Support
-------

Do you enjoy this theme? Send your ideas - issues - wishes at http://theme4press.com/evolve or help in development by a donation. Thank you!



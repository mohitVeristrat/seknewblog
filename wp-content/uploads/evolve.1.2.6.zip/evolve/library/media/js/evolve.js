$(function() {
		$("#tabs").tabs({
			cookie: {
				// store cookie for 30 days, without, it would be a session cookie
				expires: 30
			}
		});
	});

    


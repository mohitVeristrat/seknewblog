<form method="get" id="search-form" action="<?php echo get_option('home'); ?>/">
<input type="text" value="Search" name="s" id="search-input" onfocus="if (this.value == 'Search') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search';}" ><input type="submit" id="search-submit" value="" >
</form>
<div id="shadow-bar"> <!-- blank --> </div>

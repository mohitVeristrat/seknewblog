		<div id="footer"> <p>Powered by <a href="http://wordpress.org"  target="_blank">WordPress</a>. &copy; designed by <a href="http://mythem.es" title="mythem.es" target="_blank">mythem.es</a></p></div>
		<?php wp_footer(); ?>
</body>
</html>
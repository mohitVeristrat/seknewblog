****************************************************************************
				my lovely theme 
****************************************************************************

- Thanks for using "my lovely theme" Wordpress theme.
- Designed By: mythem.es
- URL: www.mythem.es
- Graphics license: GNU General Public License v2.0
- License: GNU General Public License v2.0
- License URI: http://www.gnu.org/licenses/gpl-2.0.html

****************************************************************************

		     			
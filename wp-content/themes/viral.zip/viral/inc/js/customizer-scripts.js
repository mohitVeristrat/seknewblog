jQuery(document).ready(function($) {
    "use strict";

    $('#customize-info .preview-notice').append(
         '<div class="viral-info">'+
         '<a href="http://demo.hashthemes.com/viral" target="_blank">Live Demo</a>'+
         '<a href="mailto:support@hashthemes.com" target="_blank">Support & Customization <br/>------<br/> support@hashthemes.com</a>'+
         '</div>'
    );  

});
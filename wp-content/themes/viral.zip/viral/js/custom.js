jQuery(function($){
	$('.vl-toggle-menu').click(function(){
  		$('.vl-main-navigation .vl-menu').slideToggle();
    });
});